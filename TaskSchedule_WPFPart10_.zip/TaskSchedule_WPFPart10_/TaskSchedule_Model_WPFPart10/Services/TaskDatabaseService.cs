﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaskSchedule_Model_WPFPart10.Models;

namespace TaskSchedule_Model_WPFPart10.Services
{
    public class TaskDatabaseService : ITaskDatabaseService
    {
        public bool SaveTask(TblTask tblTask)
        {
            try
            {
                using (var context = new TaskScheduleDbContext())
                {
                    context.Add(tblTask);
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }

        }
        public bool DeleteTask(TblTask tblTask)
        {
            try
            {
                using (var context = new TaskScheduleDbContext())
                {
                    context.Remove(tblTask);
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }
        public bool UpdateTask(TblTask tblTask)
        {
            try
            {
                using (var context = new TaskScheduleDbContext())
                {
                    context.Update(tblTask);
                    context.SaveChanges();
                    return true;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        public List<TblTask> GetTask()
        {
            try
            {
                using (var context = new TaskScheduleDbContext())
                {
                    return context.TblTasks.ToList();
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
