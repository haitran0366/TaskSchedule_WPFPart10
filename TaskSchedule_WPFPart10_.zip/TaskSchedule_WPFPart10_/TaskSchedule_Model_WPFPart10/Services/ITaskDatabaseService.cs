﻿using System.Collections.Generic;
using TaskSchedule_Model_WPFPart10.Models;

namespace TaskSchedule_Model_WPFPart10.Services
{
    public interface ITaskDatabaseService
    {
        bool DeleteTask(TblTask tblTask);
        List<TblTask> GetTask();
        bool SaveTask(TblTask tblTask);
        bool UpdateTask(TblTask tblTask);
    }
}