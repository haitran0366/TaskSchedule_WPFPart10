﻿using System;
using System.Collections.Generic;

#nullable disable

namespace TaskSchedule_Model_WPFPart10.Models
{
    public partial class TblTask
    {
        public int Id { get; set; }
        public string TaskName { get; set; }
        public string Description { get; set; }
        public DateTime? DueDate { get; set; }
    }
}
